To follow the workshop, the following software and files have to be downloaded:

* MapFish Print WAR and CLI: http://mapfish.github.io/mapfish-print-doc/download.html
* Tomcat: https://tomcat.apache.org/download-80.cgi
* JasperSoft Studio: http://community.jaspersoft.com/project/jaspersoft-studio/releases

The workshop has been tested on a OSGeo Live system (Ubuntu).
